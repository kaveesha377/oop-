package com.user;

import java.util.Properties;

import javax.mail.*;
import javax.mail.internet.*;

public class email {

	public static boolean sendEmail(String name, String email, String textarea) {
		boolean isSuccess = false;

		String username = "hr@teleios.lk";
		String password = "?d6GJHe50EAh";

		Properties prop = new Properties();
		prop.put("mail.smtp.host", "mail.teleios.lk");
		prop.put("mail.smtp.port", "26");
		prop.put("mail.smtp.auth", "true");
		prop.put("mail.smtp.starttls.enable", "true"); // TLS

		Session session = Session.getInstance(prop, new javax.mail.Authenticator() {
			protected PasswordAuthentication getPasswordAuthentication() {
				return new PasswordAuthentication(username, password);
			}
		});

		try {

			Message message = new MimeMessage(session);
			message.setFrom(new InternetAddress("hr@teleios.lk"));
			message.setRecipients(Message.RecipientType.TO, InternetAddress.parse("nauladilan@gmail.com"));
			message.setSubject(name);
			message.setText("Email address is - "+email + "\n Message is - "+textarea);

			Transport.send(message);
			isSuccess = true;

		} catch (MessagingException e) {
			e.printStackTrace();
		}

		return isSuccess;
	}

}

package com.user;

public class User {
	private int iduser;
	private String username;
	private String password;
	private String name;
	private String address;
	private String contact;

	public User(int iduser, String username, String password, String name, String address, String contact) {
		super();
		this.iduser = iduser;
		this.username = username;
		this.password = password;
		this.name = name;
		this.address = address;
		this.contact = contact;
	}

	public int getIduser() {
		return iduser;
	}

	public String getUsername() {
		return username;
	}

	public String getPassword() {
		return password;
	}

	public String getName() {
		return name;
	}

	public String getAddress() {
		return address;
	}

	public String getContact() {
		return contact;
	}

}

package com.user;

public class CartDetails {
	private int cart_id;
	private String img;
	private String item;
	private int qty;
	private Double amount;
	private String username;
	private Double price;

	public CartDetails(int cart_id, String img, String item, int qty, Double amount, String username, Double price) {
		this.cart_id = cart_id;
		this.img = img;
		this.item = item;
		this.qty = qty;
		this.amount = amount;
		this.username = username;
		this.price = price;

	}

	public int getCart_id() {
		return cart_id;
	}

	public String getImg() {
		return img;
	}

	public String getItem() {
		return item;
	}

	public int getQty() {
		return qty;
	}

	public Double getAmount() {
		return amount;
	}

	public String getUsername() {
		return username;
	}

	public Double getPrice() {
		return price;
	}

}

package com.user;

public class Store {
	private int id;
	private String name;
	private double price;
	private String img;
	private int type;

	public Store(int id, String name, double price, String img, int type) {
		this.id = id;
		this.name = name;
		this.price = price;
		this.img = img;
		this.type = type;
	}

	public int getId() {
		return id;
	}

	public String getName() {
		return name;
	}

	public double getPrice() {
		return price;
	}

	public String getImg() {
		return img;
	}

	public int getType() {
		return type;
	}

}

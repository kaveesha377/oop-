package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.user.CartDetails;
import com.util.CartViewUtil;
import com.util.ConfirmPaymentUtil;

import jdk.internal.dynalink.beans.StaticClass;

/**
 * Servlet implementation class ConfirmPayment
 */
@WebServlet("/ConfirmPayment")
public class ConfirmPayment extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

		String user = request.getSession().getAttribute("getUserSession").toString();
		String type = request.getParameter("type");

		if (type.equals("bank")) {
			request.setAttribute("pType", "bank");
			ConfirmPaymentUtil.cartDetails(user);
			RequestDispatcher dis = request.getRequestDispatcher("payment.jsp");
			dis.forward(request, response);
		} else if (type.equals("card")) {
			request.setAttribute("pType", "card");
			ConfirmPaymentUtil.cartDetails(user);
			RequestDispatcher dis = request.getRequestDispatcher("payment.jsp");
			dis.forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

package com.servlets;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.util.ConfirmPaymentUtil;

/**
 * Servlet implementation class CartToStore
 */
@WebServlet("/CartToStore")
public class CartToStore extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		String btn = request.getParameter("btn1");

		if (btn.equals("Clear Cart")) {

			String user = request.getSession().getAttribute("getUserSession").toString();
			ConfirmPaymentUtil.deleteCart(user);
			
			RequestDispatcher dis = request.getRequestDispatcher("cart-view");
			dis.forward(request, response);

		} else if (btn.equals("Continue Shopping")) {
			RequestDispatcher dis = request.getRequestDispatcher("store");
			dis.forward(request, response);
		}

	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

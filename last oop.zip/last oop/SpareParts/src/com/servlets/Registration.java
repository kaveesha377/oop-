package com.servlets;

import java.io.IOException;
import java.util.List;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.user.User;
import com.util.LoginUtil;

/**
 * Servlet implementation class Registration
 */
@WebServlet("/Registration")
public class Registration extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		String btn = request.getParameter("btn");
		if (btn.equals("btn2")) {
			// Registration Part
			String name = request.getParameter("name");
			String address = request.getParameter("address");
			String contact = request.getParameter("contact");
			String uname = request.getParameter("uname");
			String pass = request.getParameter("password");

			boolean isTrue;
			isTrue = com.util.LoginUtil.customerReg(uname, pass, name, address, contact);

			if (isTrue == true) {
				request.setAttribute("msg", "true");
				RequestDispatcher dis = request.getRequestDispatcher("login.jsp");
				dis.forward(request, response);

			} else {
				request.setAttribute("msg", "false");
				RequestDispatcher dis = request.getRequestDispatcher("login.jsp");
				dis.forward(request, response);
			}
		} else if (btn.equals("btn1")) {
			// Login Part
			String logUname = request.getParameter("logUname");
			String logPword = request.getParameter("logPword");
			boolean isTrue;

			isTrue = LoginUtil.userVerification(logUname, logPword);
			if (isTrue == true) {
				
				HttpSession session = request.getSession(true);
				session.setAttribute("getUserSession", logUname);

				List<User> userDetails = LoginUtil.userDetails(logUname);
				request.setAttribute("userDetails", userDetails);
				
				LoginUtil.SetUserName = logUname;

				RequestDispatcher rd = request.getRequestDispatcher("cart-view");
				rd.forward(request, response);
			} else {
				request.setAttribute("msg2", "false");
				RequestDispatcher rd = request.getRequestDispatcher("login.jsp");
				rd.forward(request, response);
			}

		}
	}

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse
	 *      response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		// TODO Auto-generated method stub
		doGet(request, response);
	}

}

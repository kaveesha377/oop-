package com.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.user.CartDetails;

public class CartViewUtil {

	private static Connection con;
	private static Statement statement;
	private static ResultSet rs;
	private static Double total = 0.0;
	private static Double setTotal;
	public static Double discount;
	public static Double payable;

	public static List<CartDetails> cartDetails(String getUserName) {
		ArrayList<CartDetails> cDetails = new ArrayList<CartDetails>();

		try {
			con = DatabaseConnection.getConnection();
			statement = con.createStatement();
			String sql = "select * from cart where username='" + getUserName + "'";
			rs = statement.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt(1);
				String img = rs.getString(2);
				String item = rs.getString(3);
				int qty = rs.getInt(4);
				Double amount = rs.getDouble(5);
				String username = rs.getString(6);
				Double price = rs.getDouble(7);

				total = total + amount;

				CartDetails cd = new CartDetails(id, img, item, qty, amount, username, price);
				cDetails.add(cd);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return cDetails;
	}

	public static Double getTot() {
		setTotal = total;

		if (setTotal > 75000.0) {
			discount = (setTotal * 5) / 100;
		} else {
			discount = 0.0;
		}
		payable = setTotal - discount;
		total = 0.0;
		return setTotal;
	}

}

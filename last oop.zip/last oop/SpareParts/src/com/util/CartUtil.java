package com.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import com.user.Store;
import com.user.User;

public class CartUtil {
	private static Connection con = null;
	private static Statement statment = null;
	private static ResultSet rs = null;

	private static String itemName;
	private static Double itemPrice;
	private static String itemImg;
	private static int getQty;
	private static Double getAmount;

	public static boolean itemDetails(int id, String qty, String userName) {
		boolean isSuccess = false;
		try {
			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "select * from items where itemId='" + id + "'";
			rs = statment.executeQuery(sql);
			while (rs.next()) {

				itemName = rs.getString(2);
				itemPrice = rs.getDouble(3);
				itemImg = rs.getString(4);
				getQty = Integer.parseInt(qty);
				getAmount = getQty * itemPrice;
				insertCartData(userName);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return isSuccess;
	}

	public static void insertCartData(String userName) {

		try {

			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "INSERT INTO cart (img, item, qty, amount, username,price) VALUES ('" + itemImg + "', '"
					+ itemName + "', '" + getQty + "', '" + getAmount + "', '" + userName + "','" + itemPrice + "')";

			statment.executeUpdate(sql);

		} catch (Exception e) {
			e.printStackTrace();
		}
	}

}

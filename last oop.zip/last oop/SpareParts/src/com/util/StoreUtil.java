package com.util;

import java.sql.Connection;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import com.user.Store;

public class StoreUtil {

	private static Connection con = null;
	private static Statement statment = null;
	private static ResultSet rs = null;

	public static List<Store> allItems() {
		ArrayList<Store> store = new ArrayList<Store>();

		try {
			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "select * from items";
			rs = statment.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				String img = rs.getString(4);
				int type = rs.getInt(5);

				Store s = new Store(id, name, price, img, type);
				store.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return store;
	}

	public static List<Store> typeOne() {
		ArrayList<Store> store = new ArrayList<Store>();

		try {
			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "select * from items where type=1";
			rs = statment.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				String img = rs.getString(4);
				int type = rs.getInt(5);

				Store s = new Store(id, name, price, img, type);
				store.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return store;
	}

	public static List<Store> typeTwo() {
		ArrayList<Store> store = new ArrayList<Store>();

		try {
			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "select * from items where type=2";
			rs = statment.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				String img = rs.getString(4);
				int type = rs.getInt(5);

				Store s = new Store(id, name, price, img, type);
				store.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return store;
	}

	public static List<Store> typeThree() {
		ArrayList<Store> store = new ArrayList<Store>();

		try {
			con = DatabaseConnection.getConnection();
			statment = con.createStatement();
			String sql = "select * from items where type=3";
			rs = statment.executeQuery(sql);

			while (rs.next()) {
				int id = rs.getInt(1);
				String name = rs.getString(2);
				double price = rs.getDouble(3);
				String img = rs.getString(4);
				int type = rs.getInt(5);

				Store s = new Store(id, name, price, img, type);
				store.add(s);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}

		return store;
	}

}
